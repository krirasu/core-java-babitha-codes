package com.cg.mobilemgm.dao;

import java.util.ArrayList;



import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;



public interface MobileDao {

	public int addMob(Mobiles mob) throws MobileException;
	public int addPurDetails(PurchaseDetails pur,Mobiles mob) throws MobileException;
	public int generatePurId() throws MobileException;
	public  ArrayList<Integer> getAllMobId() throws MobileException;
	public int getMobQuan(Mobiles mob) throws MobileException;
	public int deleteMobDetails(Mobiles mob) throws MobileException;
	
	public int updateMob(Mobiles mob) throws MobileException;
	
	public  ArrayList<Mobiles> getAllMob() throws MobileException;
	
	public ArrayList<Mobiles> searchMob(float minValue, float maxValue) throws MobileException;
	
}
