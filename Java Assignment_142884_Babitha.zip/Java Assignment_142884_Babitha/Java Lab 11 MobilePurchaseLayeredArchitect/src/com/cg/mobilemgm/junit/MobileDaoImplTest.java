package com.cg.mobilemgm.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.dao.MobileDao;
import com.cg.mobilemgm.dao.MobileDaoImpl;
import com.cg.mobilemgm.exception.MobileException;


public class MobileDaoImplTest 
{
	static MobileDao mobDao = null;
	static Mobiles mob = null;
	static PurchaseDetails pur =null;
	
	@BeforeClass
	public static void beforeClass() throws MobileException
	{
		long temp = System.currentTimeMillis();
		java.sql.Date purDate = new java.sql.Date(temp);
		mobDao = new MobileDaoImpl();
		mob = new Mobiles(1003,"Sony xperia C",15000,24);
		pur = new PurchaseDetails(mobDao.generatePurId(),"Babitha","babitha@gmail.com",purDate,"9833674068",mob);
	}
	
	@Test
	public void testAddPur() throws MobileException
	{
		Assert.assertEquals(1, mobDao.addPurDetails(pur, mob));
	}
} 
