package com.cg.mobilemgm.service;


import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.dao.MobileDao;
import com.cg.mobilemgm.dao.MobileDaoImpl;
import com.cg.mobilemgm.exception.MobileException;

public class MobileServiceImpl implements MobileService {

	MobileDao mobDao = null;

	public MobileServiceImpl() {
		super();
		mobDao = new MobileDaoImpl();
	}

	@Override
	public int addMob(Mobiles mob) throws MobileException {

		return mobDao.addMob(mob);
	}

	@Override
	public int addPurDetails(PurchaseDetails pur,Mobiles mob) throws MobileException {

		return mobDao.addPurDetails(pur,mob);
	}

	@Override
	public int generatePurId() throws MobileException {

		return mobDao.generatePurId();
	}

	@Override
	public boolean validatePhoneNo(String custPhoneNo) throws MobileException {
		String numPattern = "[0-9]{10}";
		if(Pattern.matches(numPattern, custPhoneNo))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only 10 digits allowed in customer phone number.");
		}
	}

	@Override
	public boolean validatePurName(String custName) throws MobileException {
		String namePattern = "[A-Z][a-z]{1,19}";
		if(Pattern.matches(namePattern, custName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only Chars Allowed and "
					+ "starts with Capital e.g Babitha.");
		}
	}

	@Override
	public boolean validatePurEmail(String custEmail) throws MobileException {
		//String namePattern = "\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
		String namePattern = "^(.+)@(.+)$";
		if(Pattern.matches(namePattern, custEmail))
		{
			return true;
		}
		else
		{
			throw new MobileException("Invalid Email Id ...eg: xyz@gmail.com");
		}
	}

	@Override
	public boolean validateMobId(int mobId) throws MobileException {
		String pattern = "[1][0-9]{3}";
		int flag=0;
		if(Pattern.matches(pattern, new Integer(mobId).toString()))
		{

			ArrayList<Integer> mobList = mobDao.getAllMobId();
			for(int temp:mobList)
			{
				if(mobId == temp)
				{
					flag=1;
				}
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new MobileException("Invalid MobId...");
		}
	}

	@Override
	public int validateMobQuan(Mobiles mob) throws MobileException {
		
		return mobDao.getMobQuan(mob);
	}

	@Override
	public ArrayList<Mobiles> getAllMob() throws MobileException {
		
		return mobDao.getAllMob();
	}

	@Override
	public int deleteMobDetails(Mobiles mob) throws MobileException {
		
		return mobDao.deleteMobDetails(mob);
	}

	@Override
	public ArrayList<Mobiles> searchMob(float minValue, float maxValue)
			throws MobileException {
		
		return mobDao.searchMob(minValue, maxValue);
	}

	@Override
	public int updateMob(Mobiles mob) throws MobileException {
		
		return mobDao.updateMob(mob);
	}
}
