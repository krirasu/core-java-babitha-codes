
public class TestAccount {

	public static void main(String[] args) {
		
		Person smith = new Person("Smith",23);
		Account a1 = new Account(smith,(long)(Math.random()*100000),2000);
		
		a1.deposit(2000);
		
		Person kathy = new Person("Kathy",22);
		Account a2 = new Account(kathy,(long)(Math.random()*100000),3000);
		
		a2.withdraw(2000);
	
		System.out.println("Smith Details: "+a1);
		System.out.println("Current balance of Smith: "+ a1.getBalance());
		System.out.println("Kathy Details: "+a2);
		System.out.println("Current balance of Kathy: "+ a2.getBalance());
		
		
	}

}
