
public class Person {

	private String firstName;
	private String lastName;
	private char gender;
	private long phone;
	
	//Getters
	public String getFirstName(){
		return this.firstName;
	}
	public String getLastName(){
		return this.lastName;
	}
	public char getGender(){
		return this.gender;
	}
	public long getPhone(){
		return this.phone;
	}
	//Setters
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	public void setGender(char gender){
		this.gender = gender;
	}
	public void setPhone(long phone){
		this.phone = phone;
	}
	
	public Person() {
		this.firstName = null;
		this.lastName = null;
		this.gender = ' ';
	}
	
	public Person(String firstName, String lastName, char gender, long phone) {
		setLastName(lastName);
		setFirstName(firstName);
		setGender(gender);
		setPhone(phone);
	}
	
	public void dispPersonDetails(){
		System.out.println("Person Details:");
		System.out.println("---------------------------");
		System.out.println("First Name: "+getFirstName());
		System.out.println("Last Name: "+getLastName());
		System.out.println("Gender: "+getGender());
		System.out.println("Phone Number: "+getPhone());
	}
}
