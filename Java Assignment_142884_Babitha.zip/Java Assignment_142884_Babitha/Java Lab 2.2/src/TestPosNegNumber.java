
public class TestPosNegNumber {
	
	public String checkPosNeg(int number){
		if (number> 0)
			return "Number "+ number + " is Positive.";
		else if (number<0)
			return "Number "+ number + " is Negative.";
		else
			return "Number entered is zero.";
		
	}

	public static void main(String[] args) {
		int number = Integer.parseInt(args[0]);
		TestPosNegNumber test = new TestPosNegNumber();
		
		System.out.println(test.checkPosNeg(number));

	}

}
