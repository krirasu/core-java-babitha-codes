
public class ExceptionIncompleteName extends Exception {

	
		public ExceptionIncompleteName(String msg)
		{
			super(msg);
		}

	

}
