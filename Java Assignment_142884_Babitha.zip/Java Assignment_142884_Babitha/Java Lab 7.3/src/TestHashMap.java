import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Insurance;


public class TestHashMap {

	public static void main(String[] args) {
		HashMap<String,Employee> hmap = new HashMap<String,Employee>();

		Scanner s =new Scanner(System.in);
		int eId;
		String eName,eDesign,inScheme;
		float eSal;
		
		System.out.println("Enter 4 employee Details");
		
		Employee emp[] = new Employee[3];
		for (int i = 0 ; i<3 ; i++)
		{
		System.out.println("Enter Employee "+i +" Id");
		eId = s.nextInt();
		System.out.println("Enter Employee "+i +" Name");
		eName = s.next();
		System.out.println("Enter Employee "+i +" Salary");
		eSal = s.nextFloat();
		System.out.println("Enter Emloyee "+i +" Designation");
		eDesign = s.next();
		
		Insurance in = new Insurance(eSal, eDesign);
		inScheme = in.getInsuranceScheme();

		emp[i]= new Employee(eId,eName,eSal,eDesign,inScheme);
		
		}
		
	}

}
