package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;

public class MobileClient {

	public static void main(String[] args) {
		MobileService mser =  new MobileServiceImpl();
		int choice;
		Scanner sc = new Scanner(System.in);
		do{
			System.out.println("1.Add Mobile");
			System.out.println("2.Update Mobile");
			System.out.println("3.Search Mobile");
			System.out.println("4.Delete Mobile");
			System.out.println("5.Exit");
			System.out.println("Enter your choice: ");

			choice = sc.nextInt();
			int choice2;
			switch(choice){
			case 1:
				System.out.println("Enter Mobile Name: ");
				sc.nextLine();
				String mname = sc.next();
				System.out.println("Enter Price: ");
				double price = sc.nextDouble();
				System.out.println("Enter Quantity: ");
				int qty = sc.nextInt();
				Mobile mobile = new Mobile();
				mobile.setMname(mname);
				mobile.setPrice(price);
				mobile.setQty(qty);
				mser.addMobile(mobile);
				System.out.println("Mobile Details Added");

				break;
			case 2:
				System.out.println("Please Enter id to be updated");
				int id = sc.nextInt();
				Mobile mobile3 = mser.findMobile(id);
				System.out.println("Enter the new Name");
				String mname1 = sc.next();
				System.out.println("Enter the new Price");
				double price1 = sc.nextDouble();
				System.out.println("Enter the new Quantity");
				int qty1 = sc.nextInt();

				mobile3.setMname(mname1);
				mobile3.setPrice(price1);
				mobile3.setQty(qty1);
				mser.updateMobile(mobile3);
				System.out.println("Updated :) ");

				break;

			case 3:
				System.out.println("Enter mobile id to search: ");
				int mid = sc.nextInt();
				Mobile mobile1 =  mser.findMobile(mid);
				System.out.println(mobile1);
				break;
			case 4:
				System.out.println("Enter mobile id to delete: ");
				int mid1 = sc.nextInt();
				Mobile mobile2 =  mser.findMobile(mid1);
				mser.deleteMobile(mobile2);
				System.out.println("Mobile details deleted");
				break;
			case 5:
				System.exit(0);
				break;
			}

		}
		while(true);
	}
}
