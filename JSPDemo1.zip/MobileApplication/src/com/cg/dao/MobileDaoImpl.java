package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Mobile;

public class MobileDaoImpl implements MobileDao {

	EntityManager em=null;


	public MobileDaoImpl() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
	}

	@Override
	public void addMobile(Mobile mobile) {
		em.getTransaction().begin();
		em.persist(mobile);
		em.getTransaction().commit();

	}

	@Override
	public void updateMobile(Mobile mobile) {
		em.getTransaction().begin();
		em.merge(mobile);
		em.getTransaction().commit();

	}

	@Override
	public void deleteMobile(Mobile mobile) {
		em.getTransaction().begin();
		em.remove(mobile);
		em.getTransaction().commit();
	}

	@Override
	public Mobile findMobile(int mid) {
		Mobile m = em.find(Mobile.class, mid);
		return m;
	}

}
