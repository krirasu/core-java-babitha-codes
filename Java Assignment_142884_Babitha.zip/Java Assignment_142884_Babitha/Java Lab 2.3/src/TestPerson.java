
public class TestPerson {

	public static void main(String[] args) {
		Person p1 = new Person();
		Person p2 = new Person("Divya","Bharathi",'F');
		
		System.out.println("Person Details:");
		System.out.println("---------------------------");
		System.out.println("First Name: "+p2.getFirstName());
		System.out.println("Last Name: "+p2.getLastName());
		System.out.println("Gender: "+p2.getGender());
	}

}
