
public class Person {

	private String perName;
	private float perAge;
	
	public String getPerName() {
		return perName;
	}
	public void setPerName(String perName) {
		this.perName = perName;
	}
	public float getPerAge() {
		return perAge;
	}
	public void setPerAge(float perAge) {
		this.perAge = perAge;
	}
	
	
	
	public Person(String perName, float perAge) {
		
		this.perName = perName;
		this.perAge = perAge;
	}
	public Person() {

	}
	
	
	
	public String toString() {
		return "[Person Name=" + perName + ", Person Age=" + perAge + "]";
	}
}
