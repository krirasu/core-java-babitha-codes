package com.cg.mobilemgm.service;


import java.util.ArrayList;


import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;

public interface MobileService {
	public int addMob(Mobiles mob) throws MobileException;
	public int addPurDetails(PurchaseDetails pur,Mobiles mob) throws MobileException;
	public int generatePurId() throws MobileException;
	public  ArrayList<Mobiles> getAllMob() 
			throws MobileException;
	public int deleteMobDetails(Mobiles mob) throws MobileException;
	public int updateMob(Mobiles mob) throws MobileException;
	public ArrayList<Mobiles> searchMob(float minValue, float maxValue) throws MobileException;
	
	public boolean validatePhoneNo(String custPhoneNo)
			throws MobileException;
	public boolean validatePurName(String custName)
			throws MobileException;
	public boolean validatePurEmail(String custEmail)
			throws MobileException;
	public boolean validateMobId(int mobId) throws MobileException;
	public int validateMobQuan(Mobiles mob) throws MobileException;

	
}
