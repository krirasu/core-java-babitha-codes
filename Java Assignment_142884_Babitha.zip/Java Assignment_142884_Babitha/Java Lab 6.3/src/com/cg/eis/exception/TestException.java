package com.cg.eis.exception;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Insurance;

public class TestException {

	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		int eId;
		String eName,eDesign,inScheme;
		float eSal;
		System.out.println("Enter Employee Id");
		eId = s.nextInt();
		System.out.println("Enter Employee Name");
		eName = s.next();
		System.out.println("Enter Employee Salary");
		eSal = s.nextFloat();
		System.out.println("Enter Emloyee Designation");
		eDesign = s.next();
		 
		try{
			if(eSal<3000)
			{
				throw new EmployeeException("Employee Salary is less than 3000");
			}
			else
			{
				Insurance in = new Insurance(eSal, eDesign);
				inScheme = in.getInsuranceScheme();

				Employee emp = new Employee(eId,eName,eSal,eDesign,inScheme);
				System.out.println("Employee Details: "+emp.toString());
			}
			
		}
		catch(EmployeeException ee)
		{
			System.out.println("Salary of Employee should be greator than 3000");
			System.out.println(ee);
		}
		

	}

}
