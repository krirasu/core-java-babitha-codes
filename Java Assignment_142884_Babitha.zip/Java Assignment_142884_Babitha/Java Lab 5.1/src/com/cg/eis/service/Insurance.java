package com.cg.eis.service;

public class Insurance implements EmployeeService{
		private float empSal;
		private String empDesign;
		
		
		
	public float getEmpSal() {
			return empSal;
		}



		public void setEmpSal(float empSal) {
			this.empSal = empSal;
		}



		public String getEmpDesign() {
			return empDesign;
		}



		public void setEmpDesign(String empDesign) {
			this.empDesign = empDesign;
		}



	public Insurance() {
			
			
		}



	public Insurance(float empSal, String empDesign) {
			
			this.empSal = empSal;
			this.empDesign = empDesign;
		}



	@Override
	public String getInsuranceScheme() {
		if (empSal<5000 && empDesign.compareTo("Clerk")==0)
			{return "No Scheme";}
		else if((empSal>5000 && empSal<20000) && empDesign.compareTo("SystemAssociate")==0)
			{return "Scheme C";}
		else if((empSal>=20000 && empSal<40000) && empDesign.compareTo("Programmer")==0)
			{return "Scheme B";}
		else if(empSal>=40000 && empDesign.compareTo("Manager")==0)
			{return "Scheme A";}
		else return "last value";
		 
		
	}

}
