import java.util.Scanner;

public class TestPerson {

	public static void main(String[] args) {
		
		
				
				long phoneno;
				Scanner s = new Scanner(System.in);
				System.out.println("Enter Phone Number: ");
				phoneno = s.nextLong();
				
				Person p2 = new Person("Divya","Bharathi",'F',phoneno);
				p2.dispPersonDetails();
				

		}

}
