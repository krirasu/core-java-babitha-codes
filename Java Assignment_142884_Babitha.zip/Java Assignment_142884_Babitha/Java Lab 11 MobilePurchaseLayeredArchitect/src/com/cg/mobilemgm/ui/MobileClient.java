package com.cg.mobilemgm.ui;

import java.util.ArrayList;
import java.util.Scanner;


import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;
import com.cg.mobilemgm.service.MobileService;
import com.cg.mobilemgm.service.MobileServiceImpl;

public class MobileClient {
	static Scanner sc = null;
	static MobileService mobSer = null;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		mobSer = new MobileServiceImpl();
		int choice = 0;
		while(true)
		{
			System.out.println("\nWhat Do u want to Do ? ");
			System.out.println("\n1:Insert the customer and purchase details and "
					+ "Update the mobile quantity in mobiles table\n"
					+ " 2:View details of all mobiles available in the shop"
					+ "\n 3:Delete a mobile details based on mobile id\n "
					+ "4:Search mobiles based on price range\n 5:Exit");

			choice = sc.nextInt();
			switch(choice)
			{
			case 1: insertDetails();
			break;
			case 2: selectMobileDetails();
			break;
			case 3: deleteMobDetails();
			break;
			case 4: searchMobDetails();
			break;
			default:System.exit(0);
			}
		}
	}
	/*Main ends here ***********************/

	public static void searchMobDetails()
	{
		System.out.println("Enter Min Price Range of Mobile: ");
		float minPrice = sc.nextFloat();
		System.out.println("Enter Max Price Range of Mobile: ");
		float maxPrice = sc.nextFloat();
		try 
		{

			ArrayList<Mobiles> mobList = mobSer.searchMob(minPrice, maxPrice);

			for(Mobiles m:mobList)
			{
				System.out.println(m);
			}
		} 
		catch (MobileException e)
		{
			System.out.println("Some exception while fetching data");
			e.printStackTrace();
		}
	}


	public static void deleteMobDetails()
	{
		System.out.println("Enter Mobile Id: ");
		int mobId = sc.nextInt();
		try
		{
			if(mobSer.validateMobId(mobId))
			{
				Mobiles m = new Mobiles();
				m.setMobileId(mobId);
				int dataDeleted = mobSer.deleteMobDetails(m);
				if(dataDeleted==1)
				{
					System.out.println("Mobile Details Deleted...");
				}
				else 
				{
					System.out.println("May raise some exception while addition");
				}
			}
		}
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());
		}
	}

	public static void selectMobileDetails() {

		try 
		{
			ArrayList<Mobiles> mobList = mobSer.getAllMob();

			for(Mobiles m:mobList)
			{
				System.out.println(m);
			}
		} 
		catch (MobileException e)
		{
			System.out.println("Some exception while fetching data");
			e.printStackTrace();
		}

	}

	public static void insertDetails(){
		System.out.println("Enter Customer name: ");
		String custName = sc.next();
		try 
		{
			if(mobSer.validatePurName(custName))
			{
				System.out.println("Enter Cutomer EmailId: ");
				String custEmail = sc.next();
				if(mobSer.validatePurEmail(custEmail))
				{
					System.out.println("Enter Customer Phone no: ");
					String custPhoneNo =sc.next();
					if(mobSer.validatePhoneNo(custPhoneNo))
					{
						System.out.println("Enter Mobile Id: ");
						int mobId =sc.nextInt();
						if(mobSer.validateMobId(mobId))
						{
							Mobiles m = new Mobiles();
							m.setMobileId(mobId);
							System.out.println("Enter Quantity of mobile purchased: ");
							int mobQuan =sc.nextInt();
							m.setMobileQuantity(mobQuan);
							if((mobSer.validateMobQuan(m)-mobQuan)>0 && mobQuan>0)
							{
							
							if(mobSer.updateMob(m)>0)
							{
								PurchaseDetails pd = new PurchaseDetails();

								pd.setCustName(custName);
								pd.setCustEmail(custEmail);
								pd.setCustPhoneNo(custPhoneNo);
								
								int dataAdded = mobSer.addPurDetails(pd,m);

								if(dataAdded==1)
								{
									System.out.println("Purchase Details Added...");
								}
								else 
								{
									System.out.println("May raise some exception while addition");
								}	
							}
							else
							{
								System.out.println("Could not update mobile quantity");
							}
						}
							else
							{
								System.out.println("Mobile not available.");
							}
					}
				}
			}
			} 
		}
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());
		}
	}
}




